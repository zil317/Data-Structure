/*
CSE 17
Zihan Liu
Email: zil317
Homework #1 DEADLINE: August 31, 2016
Program: My Autobiography
*/ 

//define a class
public class Hw1{ 
  //add main method
  public static void main(String[] args){
    //create an array
   String[] a = new String[4]; 
   a[0] = "My name is Maggie Liu.";
   a[1] = "I'm a senior.";
   a[2] = "I major in Mechanical Engineering.";
   a[3] = "I love fishing and skiing.";
     
   //print out the array 
   for (int i=0; i<4; i++){
     System.out.print(a[i]+" ");   
   }
   
  }
  
}
  




